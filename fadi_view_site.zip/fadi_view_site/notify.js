// Replace with your actual Telegram bot token and chat ID
fetch('https://api.telegram.org/bot<YOUR_BOT_TOKEN>/sendMessage', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    chat_id: '<YOUR_CHAT_ID>',
    text: '🔔 Someone visited your Fadi View site!'
  })
});